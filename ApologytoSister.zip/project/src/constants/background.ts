export const backgroundWords = [
  "Sorry", "Please", "Forgive", "Brother", "Sister",
  "Forever", "Family", "Annoying", "SiblingLove", "Friends"
];