export const messages = [
  "Hey Sister! 👋",
  "You know who this is... 🙈",
  "Ur Crazy Unique Annoying Bro! 🦹‍♀️",
  "Not by blood, but by heart ❤️",
  "Remember all my Crazy Annoying? 🎭",
  "Ur Early Morning Alarm... 🌙",
  "The secrets we've shared... 🤫",
  "The memories we've made... ✨",
  "You're not just a friend...",
  "You're my soul sister! 💫",
  "And I messed up... 😔",
  "I'm really sorry! 🥺",
  "Please forgive me? 🙏"
];